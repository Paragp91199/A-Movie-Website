<?php
include "includes/header.php";
?>
<?php
include "includes/navbar.php";
?>

<?php
if(isset($_GET['page']))
{
    $page=$_GET['page'];
    $page=mysqli_real_escape_string($conn,$page);
    $page=htmlentities($page);
}
else
{
    $page=1;
}
$sql="select * from posts";
$res=mysqli_query($conn,$sql);
$count=mysqli_num_rows($res);
$per_page=8;
$no_of_page=ceil($count/$per_page);
$start=($page-1)*$per_page;
$sql="select * from posts limit $start,$per_page";
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res)>0)
{
?>
<div class="row">
<style>
  body{
    background-image:url(img/im.png);
    background-size: cover;
    background-attachment: fixed;
  }
</style>
<style>.list-inline{padding-top:5px;font-weight:500;font-size:15px}@media only screen and (max-width: 991px).list-inline{padding-left:0;list-style:none;margin-left:-5px;}.list-inline>li{display:inline-block;padding-left:5px;padding-right:5px}dl{margin-top:0;margin-bottom:20px}dt,dd{line-height:1.42857}dt{font-weight:bold}dd{margin-left:0}.list-inline{padding:10px 0}.home-categories{margin:10px 0;text-align:center;}.home-categories a{color:white;display:inline-block;margin:5px 5px;background:teal;line-height:25px;padding:4px 15px;font-weight:500;border-radius:10px;font-family:monospace}.home-categories a:hover{text-decoration:none;background:#7e9aff}</style>
<br>
<div class="home-categories">
    <ul class="list-inline">
        <a href="https://moviesflix.de/1080p-movies/">
              1080p Movies
            </a><a href="">
              300Mb Movies
            </a><a href="">
              720p HEVC Movies
            </a><a href="">
              Bollywood Movies
            </a><a href="">
              Bollywood Mp3 Songs
            </a><a href="">
              Bollywood Video Songs
            </a><a href="">
              Dual Audio
            </a><a href="">
              English TV Shows
            </a><a href="bed/">
              Hindi Dubbed
            </a><a href="">
              Hindi TV Shows
            </a><a href="-movies/">
              Hollywood Movies
            </a><a href="-movies/">
              Malayalam Movies
            </a><a href="ovies/">
              Marathi Movies
            </a><a href="vies/">
              Mobile Movies
            </a><a href="io/">
              Multi Audio
            </a><a href="">
              Pc Games
            </a><a href="se/">
              Pre Release
            </a><a href="ovies/">
              Punjabi Movies
            </a><a href="">
              Single Video Songs
            </a><a href="ies/">
              Tamil Movies
            </a><a href="vies/">
              Telugu Movies
            </a><a href="">
              Trailers
            </a><a href="">
              Uncategorized
            </a><a href="">
              WEB Series
            </a><div class="clearfix"></div>
    </ul>
</div>
<br>
<div class="col l9 m9 s12">
<?php
while($x=mysqli_fetch_assoc($res))
{
    ?>
    <div class="col l3 m4 s6">
    <div class="card small">
    <div class="card-image">
    <a href="post.php?id=<?php echo $x['id'];?>"><img width="auto" height="auto" src="img/<?php echo $x['feature_image'];?>" alt=""></a>
    </div>
    <div class="card-content center">
        <style>p:hover {
  color: #34963c;
}</style>
    <p style="margin: -18px;"><a href="post.php?id=<?php echo $x['id'];?>" style="font-family: cursive;"><?php echo $x['title'];?></a></p>
    </div>
    </div>
    </div>
    <?php
}
?>
<ul class="pagination center">
<li
<?php
if($page==1)
echo "class='disabled'"
?>
><a href="indexxxx.php?page=<?php echo $page-1; ?>
"><i class="material-icons">chevron_left</i></a></li>
<?php
for($i=1;$i<=$no_of_page;$i++)
{
    ?>
    <li
    
    <?php
    if($page==$i)
    echo "class='active'";  
    ?> ><a href="index.php?page=<?php echo $i;?>"><?php echo $i;?></a></li>
    <?php

}
?>
<li
<?php
if($page==$no_of_page)
echo "class='disabled'"
?>
><a href="index.php?page=<?php
echo $page+1;
?>"><i class="material-icons">chevron_right</i></a></li>
</ul>
</div>
<?php
}
else
{
    header("Location: index.php?page=1");
}
  
?>



<!-- This is sidebar area-->
<div class="col l3 m3 s12" >
<?php
include "includes/sidebar.php";
?>

</div>

<?php
include "includes/footer.php";
?>