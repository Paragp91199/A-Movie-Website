    <div class="home-section">
        <div class="nav-bar">
            <div class="wrapper">
                <ul>
                    <li><a href="">Home</a></li>
                    <li><a href="">Home</a></li>
                    <li><a href="">Home</a></li>
                    <li><a href="">Home</a></li>
                </ul>
                <form action="">
                    <input type="text" name="search" placeholder="Search">
                </form>
            </div>
        </div>
</div>