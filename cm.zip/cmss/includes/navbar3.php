<div class="navbar-fixed">
<nav class="teal">
<div class="nav-wrapper">
<div class="container">
<a href="index.php" class="brand-logo right">TonyStark</a>
<a href="" class="button-collapse" data-activates="sidenav"><i class="material-icons">menu</i></a>
          <div class="search1">       
              <form action="search.php" method="GET"> 
                <input type="text1" placeholder="Search Here..."name="search"> 
                <button type="submit" name="submit"><i class="fa fa-search"></i></button>
                
              </form> 
          </div>
<!--STYLE FOR DROPDOWN ONLY-->
<style>
  /* styling search bar */ 
  .search1 input[type=text1]{ 
              width:238px; 
              height:34px; 
              border-radius:34px; 
              border: none; 
    
          } 
            
          .search1{ 
              float:right; 
              margin:0px; 
    
          } 
            
          .search1 button{ 
              background-color: #ffffff00; 
              color: #f2f2f2; 
              float: right; 
              padding: 0px 0px 0px 16px;
              border-radius: 0px; 
              margin: -1px 103px 53px -11px; 
              font-size: 31px; 
              border: none; 
              cursor: pointer; 
          }  
.dropdowna {
  float: left;
  overflow: hidden;
}

.dropdowna .dropbtna {
  font-size: 17px;  
  border: none;
  outline: none;
  color: white;
  padding: 0px 24px 0px 7px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

a:hover, .dropdowna:hover .dropbtna {
  background-color: ;
}

.dropdown-contenta {
  display: none;
  position: absolute;
  background-color: #ddd;
  min-width: 160px;
  min-height: 130px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-contenta a {
  float: none;
  color: black;
  padding: 0px 16px;
  text-decoration: none;
  display: block;
  text-align: center;
}

.dropdown-contenta a:hover {
  background-color: #C0C0C0;
}

.dropdowna:hover .dropdown-contenta {
  display: block;
}
</style>
<!--style for Search bar-->
<ul class="hide-on-small-and-down left">
<li><a href="index.php"><i class="fa fa-fw fa-home"></i> Home</a></li>
<li><a href=""><i class="fa fa-fw fa-envelope"></i> Visit Us</a></li>
<li><a href="about.php"><i class="fa fa-fw fa-user"></i> About Us</a></li>
<div class="dropdowna">
    <button class="dropbtna">🎬 Movies <i class="fa fa-caret-down"></i></button>
    <div class="dropdown-contenta">
      <a href="#">Latest Released</a>
      <a href="#">Hollywood</a>
      <a href="#">Hacking Movies</a>
      <a href="#">Hacking Movies</a>
      <a href="#">Hacking Movies</a>
    </div>
  </div>
  <div class="dropdowna">
    <button class="dropbtna">📺 Tv Shows <i class="fa fa-caret-down"></i></button>
    <div class="dropdown-contenta">
      <a href="#">Action Series</a>
      <a href="#">Animation Series</a>
      <a href="#">Sci-Fi Series</a>
      <a href="#">Sci-Fi Series</a>
      <a href="#">Horror Series</a>
    </div>
  </div>
</ul>
</div>
</div>
</nav>
</div>
<ul id="sidenav" class="side-nav">
<ul id="menu-top" class="menu clearfix toggle-menu"><li id="menu-item-10682" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-10682"><a href="" data-wpel-link="internal">🏠 Home</a></li>

<li id="menu-item-10678" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10678"><a href="https://gamesflix.net/" data-wpel-link="external" target="_blank" rel="nofollow external noopener noreferrer">🎮 PC Games</a></li>
</ul>
</ul>
