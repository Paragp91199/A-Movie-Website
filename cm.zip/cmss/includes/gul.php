 
      
    <link rel="stylesheet" href= 
"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 


<style> 
          
        
.dropdownaa {
  float: left;
  overflow: hidden;
}

.dropdownaa .dropbtnaa {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 11px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.dropdownaa:hover .dropbtnaa{
  background-color: #f2f2f2;
  color: black;
}

.dropdownaa-content {
  display: none;
  position: absolute;
  background-color: teal;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdownaa-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdownaa-content a:hover {
  background-color: #ddd;
}

.dropdownaa:hover .dropdownaa-content {
  display: block;
}
.dropdownaa:hover
{
    display: grid;
}
          /* styling navlist */ 
          .navalist1 { 
              background-color: teal; 
              position: absolute; 
              width: 100%; 
          } 
            
          /* styling navlist anchor element */ 
          .navalist1 a { 
              float:left; 
              display: block; 
              color: #f2f2f2; 
              text-align: center; 
              padding: 12px; 
              text-decoration: none; 
              font-size: 15px; 
          } 
          .navalist1-right{ 
              float:right; 
          } 
    
          /* hover effect of navlist anchor element */ 
          .navalist1 a:hover { 
              background-color: #ddd; 
              color: black; 
          } 
            
          /* styling search bar */ 
          .search1 input[type=text1]{ 
              width:300px; 
              height:34px; 
              border-radius:1px; 
              border: none; 
    
          } 
            
          .search1{ 
              float:right; 
              margin:7px; 
    
          } 
            
          .search1 button{ 
              background-color: #4caf50; 
              color: #f2f2f2; 
              float: right; 
              padding: 5px 10px; 
              margin-right: 16px; 
              font-size: 16px; 
              border: none; 
              cursor: pointer; 
          }  
      </style> 
  </head> 
    
  <body> 
        
      <!-- Navbar items -->
          <div class="navbar-fixed">
      <div class="navalist1"> 
      
          <a href="#">Home</a> 
          <a href="#">Our Products</a> 
          <a href="#">Careers</a> 
          <a href="#">About Us</a> 
          <a href="#">Contact Us</a> 
          <div class="dropdownaa">
    <button class="dropbtnaa">Movies 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdownaa-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </div>
  <div class="navbar">
  <a href="index.php" class="brand-logo right">TonyStark</a>
        </div>
         <!-- seach bar right align -->
          <div class="search1"> 
                
              <form action="search.php" method="GET"> 
                  <input type="text1" placeholder=" Search Courses" name="search"> 
                  <button type="submit" name="submit"><i class="fa fa-search"> 
                      </i> 
                      
                  </button> 
              </form> 
          </div> 
      </div> 
      </div>