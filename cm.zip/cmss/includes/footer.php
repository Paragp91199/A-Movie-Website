<footer class="page-footer teal">
<div class="container">
Theme Developed By, MARK85
<span class="right">
Follow Us On
<a href="" class="btn btn-floating black"><i class="fa fa-facebook" aria-hidden="true"></i></a>

<a href="" class="btn btn-floating black"><i class="fa fa-instagram" aria-hidden="true"></i></a>
<a href="" class="btn btn-floating black"><i class="fa fa-twitter" aria-hidden="true"></i></a>
<a href="" class="btn btn-floating black"><i class="fa fa-youtube" aria-hidden="true"></i></a>
</span> 
</div>
<div class="clearfix"></div>

<div class="footer-copyright">
<div class="container">
&copy; All Right Reserved,Tonystark
</div>
</div>
</footer>
<!--Import jQuery before materialize.js-->
<script type="text/javascript" src="js/jquery.js"></script>
  <script type="text/javascript" src="js/materialize.min.js"></script>
  <script>
    $(document).ready(function () {
      // Custom JS & jQuery here
      $('.button-collapse').sideNav();
    });
  </script>
</body>

</html>