<?php
$dbservername="localhost";
$dbuser="id13828652_mark85";
$dbpass="Paulstark11@";
$dbname="id13828652_tonystark";
$conn=mysqli_connect($dbservername,$dbuser,$dbpass,$dbname);
?>

